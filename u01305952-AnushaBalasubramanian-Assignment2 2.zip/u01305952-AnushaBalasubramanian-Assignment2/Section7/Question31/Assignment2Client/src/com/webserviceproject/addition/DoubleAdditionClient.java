package com.webserviceproject.addition;
public class DoubleAdditionClient {
	public static void main(String[] args) throws Exception {
		double value1 = 0;
		double value2 = 0;
		if (args.length == 2) 
		{
			value1 = Double.parseDouble(args[0]); 
			value2 = Double.parseDouble(args[1]);
		}
		else{
			System.out.println("Usage: java DoubleAdditionClient [double] [double]");
			System.exit(-1); 
		}
		DoubleAdditionServiceLocator factory =
				new DoubleAdditionServiceLocator();

		DoubleAddition proxy = factory.getDoubleAddition();
		double result = proxy.add(value1, value2); 
		System.out.println("Addition result is " + result);
	}
}
