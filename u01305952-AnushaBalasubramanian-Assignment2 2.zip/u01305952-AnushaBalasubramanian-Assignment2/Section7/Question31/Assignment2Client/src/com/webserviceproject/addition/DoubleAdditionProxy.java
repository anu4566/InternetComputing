package com.webserviceproject.addition;

public class DoubleAdditionProxy implements com.webserviceproject.addition.DoubleAddition {
  private String _endpoint = null;
  private com.webserviceproject.addition.DoubleAddition doubleAddition = null;
  
  public DoubleAdditionProxy() {
    _initDoubleAdditionProxy();
  }
  
  public DoubleAdditionProxy(String endpoint) {
    _endpoint = endpoint;
    _initDoubleAdditionProxy();
  }
  
  private void _initDoubleAdditionProxy() {
    try {
      doubleAddition = (new com.webserviceproject.addition.DoubleAdditionServiceLocator()).getDoubleAddition();
      if (doubleAddition != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)doubleAddition)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)doubleAddition)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (doubleAddition != null)
      ((javax.xml.rpc.Stub)doubleAddition)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.webserviceproject.addition.DoubleAddition getDoubleAddition() {
    if (doubleAddition == null)
      _initDoubleAdditionProxy();
    return doubleAddition;
  }
  
  public double add(double x, double y) throws java.rmi.RemoteException{
    if (doubleAddition == null)
      _initDoubleAdditionProxy();
    return doubleAddition.add(x, y);
  }
  
  
}