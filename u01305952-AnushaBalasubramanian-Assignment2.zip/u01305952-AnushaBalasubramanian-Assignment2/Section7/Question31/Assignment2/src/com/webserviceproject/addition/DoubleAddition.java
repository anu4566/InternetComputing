package com.webserviceproject.addition;

public class DoubleAddition {
	public double add(double x, double y) throws Exception
	{
		double result = x + y;
		return result;
	}
}
