/**
 * DoubleAdditionService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.webserviceproject.addition;

public interface DoubleAdditionService extends javax.xml.rpc.Service {
    public java.lang.String getDoubleAdditionAddress();

    public com.webserviceproject.addition.DoubleAddition getDoubleAddition() throws javax.xml.rpc.ServiceException;

    public com.webserviceproject.addition.DoubleAddition getDoubleAddition(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
